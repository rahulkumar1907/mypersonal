const jwt = require("jsonwebtoken");

const validateToken = function (req, res, next) {
    let token = req.headers["x-Auth-token"] || req.headers["x-auth-token"];


    if (!token) { return res.send({ status: false, msg: "token must be present" }) }
    try { jwt.verify(token, "functionup-uranium") }
    catch (error) { return res.send({ status: false, msg: "token is invalid" }) };
    let decodedtoken = jwt.verify(token, "functionup-uranium");
    let userLogging = decodedtoken.userId
    let userId = req.params.userId
    if (userLogging != userId) {
        return res.send({ status: false, data: "user Id doesnot exist" })
    }
    next()
}

module.exports.validateToken = validateToken