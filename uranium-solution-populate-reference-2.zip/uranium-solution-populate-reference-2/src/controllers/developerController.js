const developerModel = require("../models/developer")
const batchModel = require("../models/batch")
// problem 2
const createdeveloper = async function (req, res) {
    let developer = req.body
    let developerCreated = await developerModel.create(developer)
    res.send({ data: developerCreated })
}
// problem 3

const scholarshipdevelopers = async function (req, res) {

    let eligible = await developerModel.find({ gender: "female", percentage: { $gte: 70 } })
    res.send({ data: eligible })
}
//  problem 4
const getdevelopers = async function (req, res) {
    let name1 = req.query.name
    let per = req.query.percentage
    console.log(name1, per)
    // let developerdetail = await developerModel.find({ name: name1, percentage: { $gte: per } }).select({ name: 1, percentage: 1 })
    let developerdetails = await developerModel.find({percentage: { $gte: per } }).select({name: 1, percentage:1})
    let batchdetails = await batchModel.find({name: name1 }).select({name:1})
    let array=batchdetails.concat(developerdetails)
    res.send({ data:array })


}
module.exports.createdeveloper = createdeveloper
module.exports.scholarshipdevelopers = scholarshipdevelopers
module.exports.getdevelopers = getdevelopers

