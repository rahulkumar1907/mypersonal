const express = require('express');
const router = express.Router();

const batchController= require("../controllers/batchController")
const developerController = require('../controllers/developerController')

const { route } = require('express/lib/application');

router.get("/test-me", function (req, res) {
    res.send("My first ever api!")
})

router.post("/createbatch", batchController.createbatch  )

router.post('/createdeveloper', developerController.createdeveloper)
router.get('/scholarshipdevelopers', developerController.scholarshipdevelopers)

router.get('/getdevelopers', developerController.getdevelopers)


module.exports = router;